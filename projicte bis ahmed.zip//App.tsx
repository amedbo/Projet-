import React, { useState } from 'react';

interface SalesData {
  id: number;
  product: string;
  quantity: number;
  price: number;
}

const SalesManagement = () => {
  const [salesData, setSalesData] = useState<SalesData[]>([
    { id: 1, product: 'Product A', quantity: 10, price: 100 },
    { id: 2, product: 'Product B', quantity: 20, price: 200 },
    { id: 3, product: 'Product C', quantity: 30, price: 300 },
  ]);

  const [newProduct, setNewProduct] = useState('');
  const [newQuantity, setNewQuantity] = useState(0);
  const [newPrice, setNewPrice] = useState(0);

  const handleAddSale = () => {
    const newSale: SalesData = {
      id: salesData.length + 1,
      product: newProduct,
      quantity: newQuantity,
      price: newPrice,
    };
    setSalesData([...salesData, newSale]);
    setNewProduct('');
    setNewQuantity(0);
    setNewPrice(0);
  };

  const handleDeleteSale = (id: number) => {
    setSalesData(salesData.filter((sale) => sale.id !== id));
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Sales Management</h1>
      <div className="flex flex-col mb-4">
        <label className="text-lg font-bold mb-2">Add New Sale</label>
        <input
          type="text"
          value={newProduct}
          onChange={(e) => setNewProduct(e.target.value)}
          placeholder="Product"
          className="p-2 mb-2 border border-gray-300 rounded"
        />
        <input
          type="number"
          value={newQuantity}
          onChange={(e) => setNewQuantity(Number(e.target.value))}
          placeholder="Quantity"
          className="p-2 mb-2 border border-gray-300 rounded"
        />
        <input
          type="number"
          value={newPrice}
          onChange={(e) => setNewPrice(Number(e.target.value))}
          placeholder="Price"
          className="p-2 mb-2 border border-gray-300 rounded"
        />
        <button
          onClick={handleAddSale}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Add Sale
        </button>
      </div>
      <div className="flex flex-col">
        <h2 className="text-2xl font-bold mb-4">Sales Data</h2>
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr>
              <th className="p-2 border border-gray-300">ID</th>
              <th className="p-2 border border-gray-300">Product</th>
              <th className="p-2 border border-gray-300">Quantity</th>
              <th className="p-2 border border-gray-300">Price</th>
              <th className="p-2 border border-gray-300">Actions</th>
            </tr>
          </thead>
          <tbody>
            {salesData.map((sale) => (
              <tr key={sale.id}>
                <td className="p-2 border border-gray-300">{sale.id}</td>
                <td className="p-2 border border-gray-300">{sale.product}</td>
                <td className="p-2 border border-gray-300">{sale.quantity}</td>
                <td className="p-2 border border-gray-300">{sale.price}</td>
                <td className="p-2 border border-gray-300">
                  <button
                    onClick={() => handleDeleteSale(sale.id)}
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesManagement;